# bibliothèques 
import numpy as np
import matplotlib.pyplot as plt
import datetime 
#-------------------------------------------------------------------------


#Lecture des donnees dans un fichier.

Faux = np.loadtxt('../DONNEES/consommation_2014_2018.txt',skiprows=1)
Iind = np.where(Faux[:,:] < -990.)
Faux[Iind] = np.nan
Iconsan = Faux[:,0]
Iconsmois = Faux[:,1]
Fconsstock = Faux[:,2]
Fconstot = Faux[:,3]
Fconsres = Faux[:,4]
Fconsauto = Faux[:,5]

Inbdate = len(Iprodan)
Fconsan = Iconsan + Iconsmois/12.5

Faux = np.loadtxt('../DONNEES/production_solaire_2014_2018.txt'
           ,skiprows=1);
Iind = np.where(Faux[:,:] < -990.)
Faux[Iind] = np.nan
Iprodan = Faux[:,0]
Iprodmois = Faux[:,1]
Fprodstock = Faux[:,2]
Fprodres = Faux[:,3]
Fprodsol = Faux[:,4]
Fprodauto = Faux[:,5]

Inbdate = len(Iprodan)
Fprodan = Iprodan + Iprodmois/12.5

# On pourra utiliser Fprodan ou Fconsan comme variable temporelle
