# bibliothèques 
import numpy as np
import matplotlib.pyplot as plt
import datetime 
#-------------------------------------------------------------------------

def regressionlineaire(Fx,Fy,Ftstudent):
   Fybar = np.nanmean(Fy)
   Fxbar = np.nanmean(Fx)
   Fxybar = np.nanmean(Fy[:] * Fx[:])
   Fxbarybar = Fxbar * Fybar
   Fx2bar = np.nanmean(Fx[:] * Fx[:])
   Fxbar2 = Fxbar * Fxbar
   Fa = (Fxybar - Fxbarybar) / (Fx2bar-Fxbar2)
   Fb = Fybar - Fa*Fxbar
   Inbmesure = Fx.size
   Fepsilon = Fy[:] - Fa * Fx[:] - Fb
   Fsigmapsilon = (np.nansum((Fepsilon -np.nanmean(Fepsilon))**2))/ (Inbmesure-2)
   Fsigmapsilon = Fsigmapsilon**0.5
   Fconf_inter = Ftstudent * Fsigmapsilon * (((Fx - Fxbar)**2)/(np.nansum((Fx - Fxbar)**2)) + 1/Inbmesure)**0.5
   return Fa,Fb,Fa*Fx+Fb-Fconf_inter , Fa*Fx+Fb+Fconf_inter ;

def tendance(Fx,Fy,Slegende,Fstudent):
   Fa, Fb, Fborneinf, Fbornesup = regressionlineaire(Fx,Fy,Fstudent)
   print(Slegende,'Tendance annuelle kWh/an',Fa)
   plt.plot(Fx,
             Fy,
             marker='+',
             color='r',
             ms=3,mec='r',
             mew=1,
             label=Slegende);
   plt.plot(Fx,
             Fa*Fx + Fb,
             ms=3,mec='b',
             mew=1,
             linestyle='-',
             linewidth=1,
             label='Tendance '+str(round(Fa))+' kWh/an')
   plt.plot(Fx,
             Fa*Fx + Fb - Fborneinf,
             ms=3,mec='r',
             mew=1,
             linestyle='-',
             linewidth=1)
 #            label='Borne inf.');
   plt.plot(Fx,
             Fa*Fx + Fb + Fbornesup,
             ms=3,mec='r',
             mew=1,
             linestyle='-',
             linewidth=1 )
#             label='Borne sup.');
    
   plt.xlabel("Annee [an]", fontsize=18);
   plt.ylabel("Energie (kWh)", fontsize=18);
   plt.legend()
   plt.show()
   return


#Lecture des donnees dans un fichier.

Faux = np.loadtxt('../DONNEES/consommation_2014_2018.txt',skiprows=1)
Iind = np.where(Faux[:,:] < -990.)
Faux[Iind] = np.nan
Iconsan = Faux[:,0]
Iconsmois = Faux[:,1]
Fconsstock = Faux[:,2]
Fconstot = Faux[:,3]
Fconsres = Faux[:,4]
Fconsauto = Faux[:,5]

Inbdate = len(Iconsan)
Fconsan = Iconsan + Iconsmois/12.5


Faux = np.loadtxt('../DONNEES/production_solaire_2014_2018.txt'
           ,skiprows=1);
Iind = np.where(Faux[:,:] < -990.)
Faux[Iind] = np.nan
Iprodan = Faux[:,0]
Iprodmois = Faux[:,1]
Fprodstock = Faux[:,2]
Fprodres = Faux[:,3]
Fprodsol = Faux[:,4]
Fprodauto = Faux[:,5]

Inbdate = len(Iprodan)
Fprodan = Iprodan + Iprodmois/12.5


# Regression lineaire sur la consommation totale
Ftstudent = 1.5
tendance(A completer pour tracer une tendance...

